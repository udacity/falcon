rm -rf CMakeFiles/ CMakeCache.txt Makefile cmake_install.cmake grader_test;
cmake CMakeLists.txt;
make;