brew tap nlohmann/json; brew install nlohmann_json;
mv /usr/local/Cellar/nlohmann_json lib/nlohmann_json